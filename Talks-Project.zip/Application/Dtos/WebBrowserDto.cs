﻿
namespace Application.Dtos
{
    public class WebBrowserDto
    {
        public string Name { get; set; } = string.Empty;
        public int MajorVersion {  get; set; }
    }
}
