﻿namespace Application.Dtos
{
    public class SessionDto
    {
        public string? Description {  get; set; }
        public bool IsApproved { get; set; }
        public string? Title {  get; set; }
        
    }
}
